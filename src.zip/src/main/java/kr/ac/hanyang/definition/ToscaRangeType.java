package kr.ac.hanyang.definition;

/**
 * Created by blainechai on 2016. 8. 24..
 */
public class ToscaRangeType {
    public static final String SHORTENED_NAME = "range";
}

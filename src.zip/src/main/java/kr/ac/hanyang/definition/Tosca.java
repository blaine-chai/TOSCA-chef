package kr.ac.hanyang.definition;

/**
 * Created by blainechai on 2016. 8. 24..
 */


public class Tosca {
    public static final String TOSCA_NAMESPACE_PREFIX = "tosca";
}

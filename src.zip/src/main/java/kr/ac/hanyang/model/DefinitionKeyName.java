package kr.ac.hanyang.model;

/**
 * Created by blainechai on 2016. 10. 4..
 */
public class DefinitionKeyName extends KeyName{
    private String constraint;

    public DefinitionKeyName(){
    }

}

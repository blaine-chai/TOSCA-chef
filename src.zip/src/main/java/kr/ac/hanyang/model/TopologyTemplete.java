package kr.ac.hanyang.model;

@Deprecated
public class TopologyTemplete {

}

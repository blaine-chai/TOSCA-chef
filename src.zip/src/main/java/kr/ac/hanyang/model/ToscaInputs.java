package kr.ac.hanyang.model;

import java.util.LinkedHashMap;

/**
 * Created by blainechai on 2016. 5. 30..
 */
public class ToscaInputs extends LinkedHashMap {
}

package kr.ac.hanyang.model;

import java.util.ArrayList;

/**
 * Created by blainechai on 2016. 10. 4..
 */
public class DefinitionKeyNames extends ArrayList<DefinitionKeyName> {
}

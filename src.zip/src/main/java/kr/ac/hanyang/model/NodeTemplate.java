package kr.ac.hanyang.model;

import kr.ac.hanyang.interfaces.basemodel.TagDefinition;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by blainechai on 2016. 5. 25..
 */

/**
 * Keyname
 * Required
 * Type
 * Description
 * <p>
 * type
 * yes
 * string
 * The required name of the Node Type the Node Template is based upon.
 * <p>
 * description
 * no
 * description
 * An optional description for the Node Template.
 * <p>
 * directives
 * no
 * string[]
 * An optional list of directive values to provide processing instructions to orchestrators and tooling.
 * properties
 * no
 * list of property assignments
 * An optional list of property value assignments for the Node Template.
 * <p>
 * attributes
 * no
 * list of attribute assignments
 * An optional list of attribute value assignments for the Node Template.
 * <p>
 * requirements
 * no
 * list of requirement assignments
 * An optional sequenced list of requirement assignments for the Node Template.
 * <p>
 * capabilities
 * no
 * list of capability assignments
 * An optional list of capability assignments for the Node Template.
 * <p>
 * interfaces
 * no
 * list of interface definitions
 * An optional list of named interface definitions for the Node Template.
 * <p>
 * artifacts
 * no
 * list of artifact definitions
 * An optional list of named artifact definitions for the Node Template.
 * <p>
 * node_filter
 * no
 * node filter
 * The optional filter definition that TOSCA orchestrators would use to select the correct target node. This keyname is only valid if the directive has the value of “selectable” set.
 * <p>
 * copy
 * no
 * string
 * The optional (symbolic) name of another node template to copy into (all keynames and values) and use as a basis for this node template.
 * <p>
 * Grammar
 * <node_template_name>:
 * type: <node_type_name>
 * description: <node_template_description>
 * directives: [<directives>]
 * properties:
 * <property_assignments>
 * attributes:
 * <attribute_assignments>
 * requirements:
 * - <requirement_assignments>
 * capabilities:
 * <capability_assignments>
 * interfaces:
 * <interface_definitions>
 * artifacts:
 * <artifact_definitions>
 * node_filter:
 * <node_filter_definition>
 * copy: <source_node_template_name>
 * <p>
 * <p>
 * node_template_name: represents the required symbolic name of the Node Template being declared.
 * node_type_name: represents the name of the Node Type the Node Template is based upon.
 * node_template_description: represents the optional description string for Node Template.
 * directives: represents the optional list of processing instruction keywords (as strings) for use by tooling and orchestrators.
 * property_assignments: represents the optional list of property assignments for the Node Template that provide values for properties defined in its declared Node Type
 * attribute_assignments: represents the optional list of attribute assignments for the Node Template that provide values for attributes defined in its declared Node Type.
 * requirement_assignments: represents the optional sequenced list of requirement assignments for the Node Template that allow assignment of type-compatible capabilities, target nodes, relationships and target (node filters) for use when fulfilling the requirement at runtime.
 * capability_assignments: represents the optional list of capability assignments for the Node Template that augment those provided by its declared Node Type.
 * interface_definitions: represents the optional list of interface definitions for the Node Template that augment those provided by its declared Node Type.
 * artifact_definitions: represents the optional list of artifact definitions for the Node Template that augment those provided by its declared Node Type.
 * node_filter_definition: represents the optional node filter TOSCA orchestrators would use for selecting a matching node template.
 * source_node_template_name: represents the optional (symbolic) name of another node template to copy into (all keynames and values) and use as a basis for this node template.
 **/
public class NodeTemplate extends LinkedHashMap implements TagDefinition {
    public NodeTemplate(Map m) {
        super(m);
    }

    public NodeTemplate() {
        super();
    }

    public boolean isValid() {


        return false;
    }

    final static HashMap keyNames = new HashMap<String, Boolean>();


    final static String TYPE = "type"; //required yes
    final static String DESCRIPTION = "description";
    //    final static String NODE_TEMPLATE_NAME = "node_template_name";
    final static String DIRECTIVES = "directives"; //list


    //    private Map data;
//
//    private String nodeName;
//    private String type;
//    private String properties;
//    private String requirements;
//    private String interfaces;
//    private String capabilities;
//
//    public NodeTemplate() {
//        this.data = new LinkedHashMap();
//    }
//
//    public Map getData() {
//        return data;
//    }
//
//    public void setData(Map data) {
//        this.data = data;
//    }
//
//    public String getNodeName() {
//        return nodeName;
//    }
//
//    public void setNodeName(String nodeName) {
//        this.nodeName = nodeName;
//    }
//
//    public String getType() {
//        return type;
//    }
//
//    public void setType(String type) {
//        this.type = type;
//    }
//
//    public String getProperties() {
//        return properties;
//    }
//
//    public void setProperties(String properties) {
//        this.properties = properties;
//    }
//
//    public String getRequirements() {
//        return requirements;
//    }
//
//    public void setRequirements(String requirements) {
//        this.requirements = requirements;
//    }
//
//    public String getInterfaces() {
//        return interfaces;
//    }
//
//    public void setInterfaces(String interfaces) {
//        this.interfaces = interfaces;
//    }
//
//    public String getCapabilities() {
//        return capabilities;
//    }
//
//    public void setCapabilities(String capabilities) {
//        this.capabilities = capabilities;
//    }
}

package kr.ac.hanyang.interfaces.definition.modeling.definition;

/**
 * Created by blainechai on 2016. 9. 21..
 */

/**
 * 3.5.13 Operation definition
 */

public interface OperationDefinition {
}

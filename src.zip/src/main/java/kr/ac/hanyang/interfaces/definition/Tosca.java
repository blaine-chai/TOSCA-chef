package kr.ac.hanyang.interfaces.definition;

/**
 * Created by blainechai on 2016. 8. 24..
 */


public interface Tosca {
    public static final String TOSCA_NAMESPACE_PREFIX = "tosca";
}

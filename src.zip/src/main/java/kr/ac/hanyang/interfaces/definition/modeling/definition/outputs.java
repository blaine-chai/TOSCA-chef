/**
 * 3.8.2.4 outputs
 */

/**
 * Grammar
 * outputs:
 * <parameter_def_list>
*/
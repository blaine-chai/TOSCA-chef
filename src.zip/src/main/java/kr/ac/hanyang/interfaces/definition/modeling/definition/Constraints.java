package kr.ac.hanyang.interfaces.definition.modeling.definition;

/**
 * Created by blainechai on 2016. 9. 21..
 * <p>
 * 3.5.2 Constraint clause
 * <p>
 * Operator
 * Type
 * Value Type
 * Description
 * <p>
 * equal
 * scalar
 * any
 * Constrains a property or parameter to a value equal to (‘=’) the value declared.
 * <p>
 * greater_than
 * scalar
 * comparable
 * Constrains a property or parameter to a value greater than (‘>’) the value declared.
 * <p>
 * greater_or_equal
 * scalar
 * comparable
 * Constrains a property or parameter to a value greater than or equal to (‘>=’) the value declared.
 * <p>
 * less_than
 * scalar
 * comparable
 * Constrains a property or parameter to a value less than (‘<’) the value declared.
 * <p>
 * less_or_equal
 * scalar
 * comparable
 * Constrains a property or parameter to a value less than or equal to (‘<=’) the value declared.
 * <p>
 * in_range
 * dual scalar
 * comparable,
 * range
 * Constrains a property or parameter to a value in range of (inclusive) the two values declared.
 * Note: subclasses or templates of types that declare a property with the in_range constraint MAY only further restrict the range specified by the parent type.
 * <p>
 * valid_values
 * list
 * any
 * Constrains a property or parameter to a value that is in the list of declared values.
 * <p>
 * length
 * scalar
 * string, list, map
 * Constrains the property or parameter to a value of a given length.
 * <p>
 * min_length
 * scalar
 * string, list, map
 * Constrains the property or parameter to a value to a minimum length.
 * <p>
 * max_length
 * scalar
 * string, list, map
 * Constrains the property or parameter to a value to a maximum length.
 * <p>
 * pattern
 * regex
 * string
 * Constrains the property or parameter to a value that is allowed by the provided regular expression.
 * Note: Future drafts of this specification will detail the use of regular expressions and reference an appropriate standardized grammar.
 * <p>
 * 3.5.2 Constraint clause
 * <p>
 * Operator
 * Type
 * Value Type
 * Description
 * <p>
 * equal
 * scalar
 * any
 * Constrains a property or parameter to a value equal to (‘=’) the value declared.
 * <p>
 * greater_than
 * scalar
 * comparable
 * Constrains a property or parameter to a value greater than (‘>’) the value declared.
 * <p>
 * greater_or_equal
 * scalar
 * comparable
 * Constrains a property or parameter to a value greater than or equal to (‘>=’) the value declared.
 * <p>
 * less_than
 * scalar
 * comparable
 * Constrains a property or parameter to a value less than (‘<’) the value declared.
 * <p>
 * less_or_equal
 * scalar
 * comparable
 * Constrains a property or parameter to a value less than or equal to (‘<=’) the value declared.
 * <p>
 * in_range
 * dual scalar
 * comparable,
 * range
 * Constrains a property or parameter to a value in range of (inclusive) the two values declared.
 * Note: subclasses or templates of types that declare a property with the in_range constraint MAY only further restrict the range specified by the parent type.
 * <p>
 * valid_values
 * list
 * any
 * Constrains a property or parameter to a value that is in the list of declared values.
 * <p>
 * length
 * scalar
 * string, list, map
 * Constrains the property or parameter to a value of a given length.
 * <p>
 * min_length
 * scalar
 * string, list, map
 * Constrains the property or parameter to a value to a minimum length.
 * <p>
 * max_length
 * scalar
 * string, list, map
 * Constrains the property or parameter to a value to a maximum length.
 * <p>
 * pattern
 * regex
 * string
 * Constrains the property or parameter to a value that is allowed by the provided regular expression.
 * Note: Future drafts of this specification will detail the use of regular expressions and reference an appropriate standardized grammar.
 * <p>
 * 3.5.2 Constraint clause
 * <p>
 * Operator
 * Type
 * Value Type
 * Description
 * <p>
 * equal
 * scalar
 * any
 * Constrains a property or parameter to a value equal to (‘=’) the value declared.
 * <p>
 * greater_than
 * scalar
 * comparable
 * Constrains a property or parameter to a value greater than (‘>’) the value declared.
 * <p>
 * greater_or_equal
 * scalar
 * comparable
 * Constrains a property or parameter to a value greater than or equal to (‘>=’) the value declared.
 * <p>
 * less_than
 * scalar
 * comparable
 * Constrains a property or parameter to a value less than (‘<’) the value declared.
 * <p>
 * less_or_equal
 * scalar
 * comparable
 * Constrains a property or parameter to a value less than or equal to (‘<=’) the value declared.
 * <p>
 * in_range
 * dual scalar
 * comparable,
 * range
 * Constrains a property or parameter to a value in range of (inclusive) the two values declared.
 * Note: subclasses or templates of types that declare a property with the in_range constraint MAY only further restrict the range specified by the parent type.
 * <p>
 * valid_values
 * list
 * any
 * Constrains a property or parameter to a value that is in the list of declared values.
 * <p>
 * length
 * scalar
 * string, list, map
 * Constrains the property or parameter to a value of a given length.
 * <p>
 * min_length
 * scalar
 * string, list, map
 * Constrains the property or parameter to a value to a minimum length.
 * <p>
 * max_length
 * scalar
 * string, list, map
 * Constrains the property or parameter to a value to a maximum length.
 * <p>
 * pattern
 * regex
 * string
 * Constrains the property or parameter to a value that is allowed by the provided regular expression.
 * Note: Future drafts of this specification will detail the use of regular expressions and reference an appropriate standardized grammar.
 * <p>
 * 3.5.2 Constraint clause
 * <p>
 * Operator
 * Type
 * Value Type
 * Description
 * <p>
 * equal
 * scalar
 * any
 * Constrains a property or parameter to a value equal to (‘=’) the value declared.
 * <p>
 * greater_than
 * scalar
 * comparable
 * Constrains a property or parameter to a value greater than (‘>’) the value declared.
 * <p>
 * greater_or_equal
 * scalar
 * comparable
 * Constrains a property or parameter to a value greater than or equal to (‘>=’) the value declared.
 * <p>
 * less_than
 * scalar
 * comparable
 * Constrains a property or parameter to a value less than (‘<’) the value declared.
 * <p>
 * less_or_equal
 * scalar
 * comparable
 * Constrains a property or parameter to a value less than or equal to (‘<=’) the value declared.
 * <p>
 * in_range
 * dual scalar
 * comparable,
 * range
 * Constrains a property or parameter to a value in range of (inclusive) the two values declared.
 * Note: subclasses or templates of types that declare a property with the in_range constraint MAY only further restrict the range specified by the parent type.
 * <p>
 * valid_values
 * list
 * any
 * Constrains a property or parameter to a value that is in the list of declared values.
 * <p>
 * length
 * scalar
 * string, list, map
 * Constrains the property or parameter to a value of a given length.
 * <p>
 * min_length
 * scalar
 * string, list, map
 * Constrains the property or parameter to a value to a minimum length.
 * <p>
 * max_length
 * scalar
 * string, list, map
 * Constrains the property or parameter to a value to a maximum length.
 * <p>
 * pattern
 * regex
 * string
 * Constrains the property or parameter to a value that is allowed by the provided regular expression.
 * Note: Future drafts of this specification will detail the use of regular expressions and reference an appropriate standardized grammar.
 */


/**
 * 3.5.2 Constraint clause
 */

/**
 * Operator
 Type
 Value Type
 Description

 equal
 scalar
 any
 Constrains a property or parameter to a value equal to (‘=’) the value declared.

 greater_than
 scalar
 comparable
 Constrains a property or parameter to a value greater than (‘>’) the value declared.

 greater_or_equal
 scalar
 comparable
 Constrains a property or parameter to a value greater than or equal to (‘>=’) the value declared.

 less_than
 scalar
 comparable
 Constrains a property or parameter to a value less than (‘<’) the value declared.

 less_or_equal
 scalar
 comparable
 Constrains a property or parameter to a value less than or equal to (‘<=’) the value declared.

 in_range
 dual scalar
 comparable,
 range
 Constrains a property or parameter to a value in range of (inclusive) the two values declared.
 Note: subclasses or templates of types that declare a property with the in_range constraint MAY only further restrict the range specified by the parent type.

 valid_values
 list
 any
 Constrains a property or parameter to a value that is in the list of declared values.

 length
 scalar
 string, list, map
 Constrains the property or parameter to a value of a given length.

 min_length
 scalar
 string, list, map
 Constrains the property or parameter to a value to a minimum length.

 max_length
 scalar
 string, list, map
 Constrains the property or parameter to a value to a maximum length.

 pattern
 regex
 string
 Constrains the property or parameter to a value that is allowed by the provided regular expression.
 Note: Future drafts of this specification will detail the use of regular expressions and reference an appropriate standardized grammar.
 */

/**
 * # Scalar grammar
 <operator>: <scalar_value>
 # Dual scalar grammar
 <operator>: [ <scalar_value_1>, <scalar_value_2> ]
 # List grammar
 <operator> [ <value_1>, <value_2>, ..., <value_n> ]
 # Regular expression (regex) grammar pattern: <regular_expression_value>

 operator: represents a required operator from the specified list shown above (see section 3.5.2.1 “Operator keynames”).
 scalar_value, scalar_value_*: represents a required scalar (or atomic quantity) that can hold only one value at a time. This will be a value of a primitive type, such as an integer or string that is allowed by this specification.
 value_*: represents a required value of the operator that is not limited to scalars.
 reqular_expression_value: represents a regular expression (string) value.
 */
public interface Constraints {
}

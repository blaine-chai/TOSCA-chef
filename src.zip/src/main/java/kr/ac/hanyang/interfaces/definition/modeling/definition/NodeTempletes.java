/**
 * 3.8.2.2 node_templates
 */


/**
 * Grammar
 * node_templates:
 * <node_template_defn_1>
 * ...
 * <node_template_defn_n>
*/


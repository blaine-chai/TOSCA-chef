/**
 * 3.8.2.3 relationship_templates
 */

/**
 * Grammar
 * relationship_templates:
 * <relationship_template_defn_1>
 * ...
 * <relationship_template_defn_n>
 */
package kr.ac.hanyang.interfaces.definition;

/**
 * Created by blainechai on 2016. 8. 24..
 */
public abstract class Keyword {
    String VALID_ALIAS;
    String NAMESPACE_URI;
    String NAMESPACE_PREFIX;
    String ATTRIBUTE_NAME;
    String SHORTENED_NAME;
    String TYPE_QUALIFIED_NAME;
    String KEYWORD;
    String GRAMMAR;
}

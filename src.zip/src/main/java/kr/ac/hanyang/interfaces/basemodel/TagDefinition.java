package kr.ac.hanyang.interfaces.basemodel;

/**
 * Created by blainechai on 2016. 10. 4..
 */
public interface TagDefinition {
    public boolean isValid();
}

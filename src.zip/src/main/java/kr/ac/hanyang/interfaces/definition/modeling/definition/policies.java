/**
 * 3.8.2.6 policies
 */

/**
 * Grammar
 * policies:
 * - <policy_defn_1>
 * - ...
 * - <policy_defn_n>
 Type
 Value Type
 Description
 */
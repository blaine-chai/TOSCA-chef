 /** 3.8.2.1 inputs
 */

/**
 * Grammar
 * inputs:
 * <parameter_definition_list>

*/
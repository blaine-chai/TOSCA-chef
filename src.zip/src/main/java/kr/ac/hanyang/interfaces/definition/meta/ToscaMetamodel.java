package kr.ac.hanyang.interfaces.definition.meta;

/**
 * Created by blainechai on 2016. 9. 21..
 */

/**
 * 3.4 TOSCA Metamodel
 */
public interface ToscaMetamodel {
}

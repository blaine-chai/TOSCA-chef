package kr.ac.hanyang.interfaces;

/**
 * Created by blainechai on 2016. 6. 8..
 */
public interface OnSelected {
    public void onSelectedAction(String src, String target);
}

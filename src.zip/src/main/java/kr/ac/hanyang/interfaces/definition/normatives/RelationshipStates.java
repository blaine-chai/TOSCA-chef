package kr.ac.hanyang.interfaces.definition.normatives;

/**
 * Created by blainechai on 2016. 8. 24..
 */

/**
 * 3.3.2 Relationship States
 *
 * Value Transitional Description
 * initial no Relationship is not yet created. Relationship only exists as a template definition.
 */
public interface RelationshipStates {
}

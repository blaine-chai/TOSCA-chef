package kr.ac.hanyang.interfaces.definition.modeling.definition;

/**
 * Created by blainechai on 2016. 9. 21..
 */

/**
 * 3.5.11 Attribute assignment
 * <p>
 * short notation
 * <p>
 * <attribute_name>: <attribute_value> | { <attribute_value_expression> }
 * <p>
 * <p>
 * extened notation
 * <p>
 * <attribute_name>:
 * description: <attribute_description>
 * value: <attribute_value> | { <attribute_value_expression> }
 */
public interface AttributeAssignment {
}

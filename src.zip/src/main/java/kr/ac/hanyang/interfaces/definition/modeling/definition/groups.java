/**
 * 3.8.2.5 groups
 */

/**
 * Grammar
 * groups:
 * <group_defn_1>
 * ...
 * <group_defn_n>
*/
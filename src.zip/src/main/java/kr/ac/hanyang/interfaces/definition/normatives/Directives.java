package kr.ac.hanyang.interfaces.definition.normatives;

/**
 * Created by blainechai on 2016. 9. 21..
 */

//currently not defined
public interface Directives {

}

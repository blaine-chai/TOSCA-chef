package kr.ac.hanyang.interfaces.definition.modeling.definition;

/**
 * Created by blainechai on 2016. 9. 21..
 * <p>
 * 3.5.1 Description definition
 */

/**
 * 3.5.1 Description definition
 */

/**
 * The YAML “folded” style may also be used for multi-line descriptions which “folds” line breaks as space characters.
 */

public interface DescriptionDefinition {
    public static final String GRAMMAR = "description: <string>";
}

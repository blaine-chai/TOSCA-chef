    This package is for property and parameter in 3.2
    3.2.1 Referenced YAML Types
    3.2.2 TOSCA version
    3.2.3 TOCSA range type
        3.2.3.1 Grammar
        3.2.3.2 Keywords
    3.2.4 TOSCA list type
package kr.ac.hanyang.interfaces.definition.modeling.definition;

/**
 * Created by blainechai on 2016. 9. 21..
 */

/**
 * 3.5.5 Repository definition
 */

/**
 * Keyname
 Required
 Type
 Constraints
 Description

 description
 no
 description
 None
 The optional description for the repository.
 url
 yes
 string
 None
 The required URL or network address used to access the repository.
 credential
 no
 Credential
 None

 The optional Credential used to authorize access to the repository.
 */

/**
 * grammar
 *
 * single line
 * <repository_name>: <repository_address>
 *
 *
 * multi line
 * <repository_name>:
 description: <repository_description>
 url: <repository_address>
 credential: <authorization_credential>
 */
public interface RepositoryDefinition {
}
